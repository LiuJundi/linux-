#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>

int num = 10;

void Deal_case1();
void Deal_case2(int);
void Deal_case3(int);


void main()
{
	char c = '1';
	int val = 20;
	while(c != 0)
	{
		printf("\n=================Menu==============\n");
		printf("1  ------   listvma\n");
		printf("2  ------   findpage addr\n");
		printf("3  ------   writeval addr val\n");
		printf("0  ------   Quit\n");
		printf("=================End================\n");
		printf("Please enter your choice:");
		c = getchar();
		switch(c)
		{
			case '1':
				Deal_case1();
			break;
			case '2':
				
				Deal_case2(num);
			break;
			case '3':
				Deal_case3(val);
			break;
			case '0':
				return;
			break;
		}
		getchar();
	}
}


void Deal_case1()
{	
	int handle;
	char string[40];
	string[0] = 'l';
	string[1] = 'i';
	string[2] = 's';
	string[3] = 't';
	string[4] = 'v';
	string[5] = 'm';
	string[6] = 'a';
	string[7] = '\0';

	handle = open("/proc/mtest",O_WRONLY);
	if(handle == 0)
	{
		printf("fail to open /proc/mtest\n");
		return;
	}
	int len = write(handle, string, strlen(string));
	if(len != strlen(string))
	{
		printf("write error\n");
		return;
	}
	close(handle);

	return;
}


void Deal_case2(int val)
{
	int handle;
	char string[40];
	string[0] = 'f';
	string[1] = 'i';
	string[2] = 'n';
	string[3] = 'd';
	string[4] = 'p';
	string[5] = 'a';
	string[6] = 'g';
	string[7] = 'e';
	string[8] = ' ';

	*(long unsigned int *)(string+9) = &num;
	string[13] = '\0';

	handle = open("/proc/mtest",O_WRONLY);
	if(handle == 0)
	{
		printf("fail to open /proc/mtest\n");
		return;
	}
	int len = write(handle, string, 40);
	if(len != 40)
	{
		printf("write error\n");
		return;
	}
	close(handle);

	return;
}




void Deal_case3(int val)
{
	int handle;
	
	char string[40];

	string[0] = 'w';
	string[1] = 'r';
	string[2] = 'i';
	string[3] = 't';
	string[4] = 'e';
	string[5] = 'v';
	string[6] = 'a';
	string[7] = 'l';
	string[8] = ' ';
	
	*(int *)(string + 9) = val;
	*(long unsigned int *)(string+13) = &num;

	string[17] = '\0';

	printf("num = %d\n", num);	


	handle = open("/proc/mtest",O_WRONLY);
	if(handle == 0)
	{
		printf("fail to open /proc/mtest\n");
		return;
	}
	int len = write(handle, string, 40);
	if(len != 40)
	{
		printf("write error\n");
		return;
	}
	close(handle);
	printf("num changs to %d\n", num);
	
	return;
}

	
