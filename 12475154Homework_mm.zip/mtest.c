#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <asm/uaccess.h>
#include <linux/string.h>



#include <linux/kernel_stat.h>
#include <linux/mm.h>
#include <linux/hugetlb.h>
#include <linux/mman.h>
#include <linux/swap.h>
#include <linux/highmem.h>
#include <linux/pagemap.h>
#include <linux/ksm.h>
#include <linux/rmap.h>
#include <linux/module.h>
#include <linux/delayacct.h>
#include <linux/init.h>
#include <linux/writeback.h>
#include <linux/memcontrol.h>
#include <linux/mmu_notifier.h>
#include <linux/kallsyms.h>
#include <linux/swapops.h>
#include <linux/elf.h>

#include <asm/io.h>
#include <asm/pgalloc.h>
#include <asm/uaccess.h>
#include <asm/tlb.h>
#include <asm/tlbflush.h>
#include <asm/pgtable.h>

#define Size 1024
char buffer[Size];

int mtest_read(char *page, char **start, off_t off, int count, int *eof, void *data)
{
	int len;
	len = sprintf(page, buffer);
	return len;
}

void print_address(struct mm_struct *mm, unsigned long addr)
{
	pgd_t *pgd = pgd_offset(mm, addr);
	if(pgd_present(*pgd))
	{
		pud_t *pud = pud_offset(pgd, addr);
		if(pud_present(*pud))
		{
			pmd_t *pmd = pmd_offset(pud, addr);
			if(pmd_present(*pmd))
			{
				pte_t *pte = pte_offset_map(pmd, addr);
				
				if(pte_present(*pte))
				{
					printk("va %lx -> pa %lx\n", addr, (*(long unsigned int *)pte & (~0x3ff)) | (addr & 0x3ff));
					/*printk("va %x%lx -> pa %x%lx\n", addr,_pa(page_address(pte_page(*pte)))|(addr&0x3ff));*/
				}
				pte_unmap(pte);
			}
		}
	}
}


void Deal_buffer()
{
	if(buffer[0] == 'l')
	{
		struct mm_struct *m;
		m = current->mm;
		struct vm_area_struct *vas;
		vas = m->mmap;
		long unsigned int flag;
		
		printk(KERN_INFO "listvma\n");

		while(vas != NULL)
		{
		 	flag = vas->vm_flags;
			char r,w,x;
			if(flag & VM_READ)
				r = 'r';
			else
				r = '-';
			if(flag & VM_WRITE)
				w = 'w';
			else
				w = '-';
			if(flag & VM_EXEC)
				x = 'x';
			else
				x = '-';
			printk(KERN_INFO "0x%lX   0x%lX  %c %c %c", vas->vm_start, vas->vm_end,r,w,x);
			vas = vas->vm_next;
		}
		
	}else if(buffer[0] == 'f')
	{
		printk(KERN_INFO "findpage addr\n");
		long unsigned int add;
		add = *(long unsigned int *)(buffer+9);
		print_address(current->mm, add);
	}else if(buffer[0] == 'w')
	{
		long unsigned int add;
		int val;
		val = *(int *)(buffer + 9);
		add = *(long unsigned int *)(buffer+13);
		*(long unsigned int *)(add) = val;
		printk(KERN_INFO "writeval addr val\n");
		print_address(current->mm, add);
	}else
	{
		
		printk(KERN_INFO "Unknown command\n");
	}
}

int mtest_write(struct file *file, const char *buf, unsigned long len, void *data)
{
	copy_from_user(buffer, buf, len);
	buffer[len] = '\0';
	Deal_buffer();
	return len;
}

static int __init mtest_init(void)
{
	struct proc_dir_entry *entry=NULL;
	entry = create_proc_entry("mtest",0666,NULL);
	if(!entry)
	{
		printk(KERN_INFO "fail to create mtest!\n");
		return -1;
	}
	else
	{
		entry->read_proc = mtest_read;
		entry->write_proc = mtest_write;
	}
	return 0;
}

static void __exit mtest_exit(void)
{
	remove_proc_entry("mtest", NULL);
	printk(KERN_INFO "Goodbye.\n");
}





module_init(mtest_init);
module_exit(mtest_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Test");
MODULE_AUTHOR("XXX");







