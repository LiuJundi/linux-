#include <stdlib.h>

void main(void)
{
	int v = 69;
	char s[100];
	int val = 20;
	*(int *)(s) = v;
	*(long unsigned int *)(s+4) = &val;
	
	int v1 = *(int *)(s);
	long unsigned int v2 = *(long unsigned int *)(s+4);
	printf("v1 = %d  v2 = %lu %u\n", v1, v2,sizeof(int));
	return;
}
